import { inventoryItems, colors } from '../data/mockDatabase.js';
import { getPriceGuide } from './pricingService.js';

export function getCatalogItems() {
  return inventoryItems.map(item => ({
    ...item,
    availableColors: colors
  }));
}

export function getItemDetails({ itemNumber, itemType = 'PART', colorId, condition = 'used', region, guideType }) {
  const item = inventoryItems.find(
    product => product.itemNumber === String(itemNumber) && Number(product.colorId) === Number(colorId)
  );

  const priceGuide = getPriceGuide({ itemNumber, itemType, colorId, condition, region, guideType });

  return {
    item: item || {
      itemNumber,
      itemName: 'Unknown item',
      colorId,
      condition
    },
    priceGuide
  };
}
