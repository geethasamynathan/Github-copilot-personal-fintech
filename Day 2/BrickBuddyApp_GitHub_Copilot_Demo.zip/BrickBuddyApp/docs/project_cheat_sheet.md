# BrickBuddyApp Project Cheat Sheet

## Purpose

BrickBuddyApp is a training application for learning how to use GitHub Copilot to understand a new codebase.

## Architecture

- **UI:** React application inside `ui/src`.
- **API:** Express server inside `api`.
- **Data:** Mock in-memory data inside `api/data/mockDatabase.js`.
- **Business Logic:** Service files inside `api/services`.
- **Routing:** Express route files inside `api/routes`.
- **Controller Layer:** Request and response handling inside `api/controllers`.

## Important Code Paths

### Inventory Sync Flow

1. User opens `UserInventory.jsx`.
2. User clicks **Sync Inventory**.
3. `syncInventory()` calls `apiClient.syncInventory()`.
4. API client sends `POST /api/inventory/sync`.
5. Express route maps to `syncUserInventory()` controller.
6. Controller calls `inventorySyncService.syncInventory()`.
7. Service updates inventory lots and returns sync summary.
8. UI refreshes the inventory table.

### Pricing Flow

1. User opens `Catalog.jsx`.
2. User clicks **View Price**.
3. `handleColorClick()` calls `apiClient.getItemDetails()`.
4. API client sends `GET /api/catalog/items/details`.
5. Controller calls `catalogService.getItemDetails()`.
6. Catalog service calls `pricingService.getPriceGuide()`.
7. Pricing service maps region and guide type to the selected price field.

## Reusable Components

- `Header.jsx` - navigation header.
- `InfoCard.jsx` - dashboard metrics.
- `apiClient.js` - reusable frontend API helper.

## Common Copilot Use

Ask Copilot to explain architecture, trace flows, find endpoints, map dependencies, and identify likely bug locations.
